/*******************************************************************************
* File Name: MONITOR.h
* Version 2.50
*
* Description:
*  Contains the function prototypes and constants available to the UART
*  user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_UART_MONITOR_H)
#define CY_UART_MONITOR_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h"


/***************************************
* Conditional Compilation Parameters
***************************************/

#define MONITOR_RX_ENABLED                     (1u)
#define MONITOR_TX_ENABLED                     (1u)
#define MONITOR_HD_ENABLED                     (0u)
#define MONITOR_RX_INTERRUPT_ENABLED           (0u)
#define MONITOR_TX_INTERRUPT_ENABLED           (0u)
#define MONITOR_INTERNAL_CLOCK_USED            (1u)
#define MONITOR_RXHW_ADDRESS_ENABLED           (0u)
#define MONITOR_OVER_SAMPLE_COUNT              (8u)
#define MONITOR_PARITY_TYPE                    (0u)
#define MONITOR_PARITY_TYPE_SW                 (0u)
#define MONITOR_BREAK_DETECT                   (0u)
#define MONITOR_BREAK_BITS_TX                  (13u)
#define MONITOR_BREAK_BITS_RX                  (13u)
#define MONITOR_TXCLKGEN_DP                    (1u)
#define MONITOR_USE23POLLING                   (1u)
#define MONITOR_FLOW_CONTROL                   (0u)
#define MONITOR_CLK_FREQ                       (0u)
#define MONITOR_TX_BUFFER_SIZE                 (4u)
#define MONITOR_RX_BUFFER_SIZE                 (4u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component UART_v2_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#if defined(MONITOR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG)
    #define MONITOR_CONTROL_REG_REMOVED            (0u)
#else
    #define MONITOR_CONTROL_REG_REMOVED            (1u)
#endif /* End MONITOR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */


/***************************************
*      Data Structure Definition
***************************************/

/* Sleep Mode API Support */
typedef struct MONITOR_backupStruct_
{
    uint8 enableState;

    #if(MONITOR_CONTROL_REG_REMOVED == 0u)
        uint8 cr;
    #endif /* End MONITOR_CONTROL_REG_REMOVED */

} MONITOR_BACKUP_STRUCT;


/***************************************
*       Function Prototypes
***************************************/

void MONITOR_Start(void) ;
void MONITOR_Stop(void) ;
uint8 MONITOR_ReadControlRegister(void) ;
void MONITOR_WriteControlRegister(uint8 control) ;

void MONITOR_Init(void) ;
void MONITOR_Enable(void) ;
void MONITOR_SaveConfig(void) ;
void MONITOR_RestoreConfig(void) ;
void MONITOR_Sleep(void) ;
void MONITOR_Wakeup(void) ;

/* Only if RX is enabled */
#if( (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) )

    #if (MONITOR_RX_INTERRUPT_ENABLED)
        #define MONITOR_EnableRxInt()  CyIntEnable (MONITOR_RX_VECT_NUM)
        #define MONITOR_DisableRxInt() CyIntDisable(MONITOR_RX_VECT_NUM)
        CY_ISR_PROTO(MONITOR_RXISR);
    #endif /* MONITOR_RX_INTERRUPT_ENABLED */

    void MONITOR_SetRxAddressMode(uint8 addressMode)
                                                           ;
    void MONITOR_SetRxAddress1(uint8 address) ;
    void MONITOR_SetRxAddress2(uint8 address) ;

    void  MONITOR_SetRxInterruptMode(uint8 intSrc) ;
    uint8 MONITOR_ReadRxData(void) ;
    uint8 MONITOR_ReadRxStatus(void) ;
    uint8 MONITOR_GetChar(void) ;
    uint16 MONITOR_GetByte(void) ;
    uint8 MONITOR_GetRxBufferSize(void)
                                                            ;
    void MONITOR_ClearRxBuffer(void) ;

    /* Obsolete functions, defines for backward compatible */
    #define MONITOR_GetRxInterruptSource   MONITOR_ReadRxStatus

#endif /* End (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) */

/* Only if TX is enabled */
#if(MONITOR_TX_ENABLED || MONITOR_HD_ENABLED)

    #if(MONITOR_TX_INTERRUPT_ENABLED)
        #define MONITOR_EnableTxInt()  CyIntEnable (MONITOR_TX_VECT_NUM)
        #define MONITOR_DisableTxInt() CyIntDisable(MONITOR_TX_VECT_NUM)
        #define MONITOR_SetPendingTxInt() CyIntSetPending(MONITOR_TX_VECT_NUM)
        #define MONITOR_ClearPendingTxInt() CyIntClearPending(MONITOR_TX_VECT_NUM)
        CY_ISR_PROTO(MONITOR_TXISR);
    #endif /* MONITOR_TX_INTERRUPT_ENABLED */

    void MONITOR_SetTxInterruptMode(uint8 intSrc) ;
    void MONITOR_WriteTxData(uint8 txDataByte) ;
    uint8 MONITOR_ReadTxStatus(void) ;
    void MONITOR_PutChar(uint8 txDataByte) ;
    void MONITOR_PutString(const char8 string[]) ;
    void MONITOR_PutArray(const uint8 string[], uint8 byteCount)
                                                            ;
    void MONITOR_PutCRLF(uint8 txDataByte) ;
    void MONITOR_ClearTxBuffer(void) ;
    void MONITOR_SetTxAddressMode(uint8 addressMode) ;
    void MONITOR_SendBreak(uint8 retMode) ;
    uint8 MONITOR_GetTxBufferSize(void)
                                                            ;
    /* Obsolete functions, defines for backward compatible */
    #define MONITOR_PutStringConst         MONITOR_PutString
    #define MONITOR_PutArrayConst          MONITOR_PutArray
    #define MONITOR_GetTxInterruptSource   MONITOR_ReadTxStatus

#endif /* End MONITOR_TX_ENABLED || MONITOR_HD_ENABLED */

#if(MONITOR_HD_ENABLED)
    void MONITOR_LoadRxConfig(void) ;
    void MONITOR_LoadTxConfig(void) ;
#endif /* End MONITOR_HD_ENABLED */


/* Communication bootloader APIs */
#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_MONITOR) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))
    /* Physical layer functions */
    void    MONITOR_CyBtldrCommStart(void) CYSMALL ;
    void    MONITOR_CyBtldrCommStop(void) CYSMALL ;
    void    MONITOR_CyBtldrCommReset(void) CYSMALL ;
    cystatus MONITOR_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;
    cystatus MONITOR_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_MONITOR)
        #define CyBtldrCommStart    MONITOR_CyBtldrCommStart
        #define CyBtldrCommStop     MONITOR_CyBtldrCommStop
        #define CyBtldrCommReset    MONITOR_CyBtldrCommReset
        #define CyBtldrCommWrite    MONITOR_CyBtldrCommWrite
        #define CyBtldrCommRead     MONITOR_CyBtldrCommRead
    #endif  /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_MONITOR) */

    /* Byte to Byte time out for detecting end of block data from host */
    #define MONITOR_BYTE2BYTE_TIME_OUT (25u)
    #define MONITOR_PACKET_EOP         (0x17u) /* End of packet defined by bootloader */
    #define MONITOR_WAIT_EOP_DELAY     (5u)    /* Additional 5ms to wait for End of packet */
    #define MONITOR_BL_CHK_DELAY_MS    (1u)    /* Time Out quantity equal 1mS */

#endif /* CYDEV_BOOTLOADER_IO_COMP */


/***************************************
*          API Constants
***************************************/
/* Parameters for SetTxAddressMode API*/
#define MONITOR_SET_SPACE      (0x00u)
#define MONITOR_SET_MARK       (0x01u)

/* Status Register definitions */
#if( (MONITOR_TX_ENABLED) || (MONITOR_HD_ENABLED) )
    #if(MONITOR_TX_INTERRUPT_ENABLED)
        #define MONITOR_TX_VECT_NUM            (uint8)MONITOR_TXInternalInterrupt__INTC_NUMBER
        #define MONITOR_TX_PRIOR_NUM           (uint8)MONITOR_TXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* MONITOR_TX_INTERRUPT_ENABLED */

    #define MONITOR_TX_STS_COMPLETE_SHIFT          (0x00u)
    #define MONITOR_TX_STS_FIFO_EMPTY_SHIFT        (0x01u)
    #define MONITOR_TX_STS_FIFO_NOT_FULL_SHIFT     (0x03u)
    #if(MONITOR_TX_ENABLED)
        #define MONITOR_TX_STS_FIFO_FULL_SHIFT     (0x02u)
    #else /* (MONITOR_HD_ENABLED) */
        #define MONITOR_TX_STS_FIFO_FULL_SHIFT     (0x05u)  /* Needs MD=0 */
    #endif /* (MONITOR_TX_ENABLED) */

    #define MONITOR_TX_STS_COMPLETE            (uint8)(0x01u << MONITOR_TX_STS_COMPLETE_SHIFT)
    #define MONITOR_TX_STS_FIFO_EMPTY          (uint8)(0x01u << MONITOR_TX_STS_FIFO_EMPTY_SHIFT)
    #define MONITOR_TX_STS_FIFO_FULL           (uint8)(0x01u << MONITOR_TX_STS_FIFO_FULL_SHIFT)
    #define MONITOR_TX_STS_FIFO_NOT_FULL       (uint8)(0x01u << MONITOR_TX_STS_FIFO_NOT_FULL_SHIFT)
#endif /* End (MONITOR_TX_ENABLED) || (MONITOR_HD_ENABLED)*/

#if( (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) )
    #if(MONITOR_RX_INTERRUPT_ENABLED)
        #define MONITOR_RX_VECT_NUM            (uint8)MONITOR_RXInternalInterrupt__INTC_NUMBER
        #define MONITOR_RX_PRIOR_NUM           (uint8)MONITOR_RXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* MONITOR_RX_INTERRUPT_ENABLED */
    #define MONITOR_RX_STS_MRKSPC_SHIFT            (0x00u)
    #define MONITOR_RX_STS_BREAK_SHIFT             (0x01u)
    #define MONITOR_RX_STS_PAR_ERROR_SHIFT         (0x02u)
    #define MONITOR_RX_STS_STOP_ERROR_SHIFT        (0x03u)
    #define MONITOR_RX_STS_OVERRUN_SHIFT           (0x04u)
    #define MONITOR_RX_STS_FIFO_NOTEMPTY_SHIFT     (0x05u)
    #define MONITOR_RX_STS_ADDR_MATCH_SHIFT        (0x06u)
    #define MONITOR_RX_STS_SOFT_BUFF_OVER_SHIFT    (0x07u)

    #define MONITOR_RX_STS_MRKSPC           (uint8)(0x01u << MONITOR_RX_STS_MRKSPC_SHIFT)
    #define MONITOR_RX_STS_BREAK            (uint8)(0x01u << MONITOR_RX_STS_BREAK_SHIFT)
    #define MONITOR_RX_STS_PAR_ERROR        (uint8)(0x01u << MONITOR_RX_STS_PAR_ERROR_SHIFT)
    #define MONITOR_RX_STS_STOP_ERROR       (uint8)(0x01u << MONITOR_RX_STS_STOP_ERROR_SHIFT)
    #define MONITOR_RX_STS_OVERRUN          (uint8)(0x01u << MONITOR_RX_STS_OVERRUN_SHIFT)
    #define MONITOR_RX_STS_FIFO_NOTEMPTY    (uint8)(0x01u << MONITOR_RX_STS_FIFO_NOTEMPTY_SHIFT)
    #define MONITOR_RX_STS_ADDR_MATCH       (uint8)(0x01u << MONITOR_RX_STS_ADDR_MATCH_SHIFT)
    #define MONITOR_RX_STS_SOFT_BUFF_OVER   (uint8)(0x01u << MONITOR_RX_STS_SOFT_BUFF_OVER_SHIFT)
    #define MONITOR_RX_HW_MASK                     (0x7Fu)
#endif /* End (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) */

/* Control Register definitions */
#define MONITOR_CTRL_HD_SEND_SHIFT                 (0x00u) /* 1 enable TX part in Half Duplex mode */
#define MONITOR_CTRL_HD_SEND_BREAK_SHIFT           (0x01u) /* 1 send BREAK signal in Half Duplez mode */
#define MONITOR_CTRL_MARK_SHIFT                    (0x02u) /* 1 sets mark, 0 sets space */
#define MONITOR_CTRL_PARITY_TYPE0_SHIFT            (0x03u) /* Defines the type of parity implemented */
#define MONITOR_CTRL_PARITY_TYPE1_SHIFT            (0x04u) /* Defines the type of parity implemented */
#define MONITOR_CTRL_RXADDR_MODE0_SHIFT            (0x05u)
#define MONITOR_CTRL_RXADDR_MODE1_SHIFT            (0x06u)
#define MONITOR_CTRL_RXADDR_MODE2_SHIFT            (0x07u)

#define MONITOR_CTRL_HD_SEND               (uint8)(0x01u << MONITOR_CTRL_HD_SEND_SHIFT)
#define MONITOR_CTRL_HD_SEND_BREAK         (uint8)(0x01u << MONITOR_CTRL_HD_SEND_BREAK_SHIFT)
#define MONITOR_CTRL_MARK                  (uint8)(0x01u << MONITOR_CTRL_MARK_SHIFT)
#define MONITOR_CTRL_PARITY_TYPE_MASK      (uint8)(0x03u << MONITOR_CTRL_PARITY_TYPE0_SHIFT)
#define MONITOR_CTRL_RXADDR_MODE_MASK      (uint8)(0x07u << MONITOR_CTRL_RXADDR_MODE0_SHIFT)

/* StatusI Register Interrupt Enable Control Bits. As defined by the Register map for the AUX Control Register */
#define MONITOR_INT_ENABLE                         (0x10u)

/* Bit Counter (7-bit) Control Register Bit Definitions. As defined by the Register map for the AUX Control Register */
#define MONITOR_CNTR_ENABLE                        (0x20u)

/*   Constants for SendBreak() "retMode" parameter  */
#define MONITOR_SEND_BREAK                         (0x00u)
#define MONITOR_WAIT_FOR_COMPLETE_REINIT           (0x01u)
#define MONITOR_REINIT                             (0x02u)
#define MONITOR_SEND_WAIT_REINIT                   (0x03u)

#define MONITOR_OVER_SAMPLE_8                      (8u)
#define MONITOR_OVER_SAMPLE_16                     (16u)

#define MONITOR_BIT_CENTER                         (MONITOR_OVER_SAMPLE_COUNT - 2u)

#define MONITOR_FIFO_LENGTH                        (4u)
#define MONITOR_NUMBER_OF_START_BIT                (1u)
#define MONITOR_MAX_BYTE_VALUE                     (0xFFu)

/* 8X always for count7 implementation */
#define MONITOR_TXBITCTR_BREAKBITS8X   ((MONITOR_BREAK_BITS_TX * MONITOR_OVER_SAMPLE_8) - 1u)
/* 8X or 16X for DP implementation */
#define MONITOR_TXBITCTR_BREAKBITS ((MONITOR_BREAK_BITS_TX * MONITOR_OVER_SAMPLE_COUNT) - 1u)

#define MONITOR_HALF_BIT_COUNT   \
                            (((MONITOR_OVER_SAMPLE_COUNT / 2u) + (MONITOR_USE23POLLING * 1u)) - 2u)
#if (MONITOR_OVER_SAMPLE_COUNT == MONITOR_OVER_SAMPLE_8)
    #define MONITOR_HD_TXBITCTR_INIT   (((MONITOR_BREAK_BITS_TX + \
                            MONITOR_NUMBER_OF_START_BIT) * MONITOR_OVER_SAMPLE_COUNT) - 1u)

    /* This parameter is increased on the 2 in 2 out of 3 mode to sample voting in the middle */
    #define MONITOR_RXBITCTR_INIT  ((((MONITOR_BREAK_BITS_RX + MONITOR_NUMBER_OF_START_BIT) \
                            * MONITOR_OVER_SAMPLE_COUNT) + MONITOR_HALF_BIT_COUNT) - 1u)

#else /* MONITOR_OVER_SAMPLE_COUNT == MONITOR_OVER_SAMPLE_16 */
    #define MONITOR_HD_TXBITCTR_INIT   ((8u * MONITOR_OVER_SAMPLE_COUNT) - 1u)
    /* 7bit counter need one more bit for OverSampleCount = 16 */
    #define MONITOR_RXBITCTR_INIT      (((7u * MONITOR_OVER_SAMPLE_COUNT) - 1u) + \
                                                      MONITOR_HALF_BIT_COUNT)
#endif /* End MONITOR_OVER_SAMPLE_COUNT */

#define MONITOR_HD_RXBITCTR_INIT                   MONITOR_RXBITCTR_INIT


/***************************************
* Global variables external identifier
***************************************/

extern uint8 MONITOR_initVar;
#if (MONITOR_TX_INTERRUPT_ENABLED && MONITOR_TX_ENABLED)
    extern volatile uint8 MONITOR_txBuffer[MONITOR_TX_BUFFER_SIZE];
    extern volatile uint8 MONITOR_txBufferRead;
    extern uint8 MONITOR_txBufferWrite;
#endif /* (MONITOR_TX_INTERRUPT_ENABLED && MONITOR_TX_ENABLED) */
#if (MONITOR_RX_INTERRUPT_ENABLED && (MONITOR_RX_ENABLED || MONITOR_HD_ENABLED))
    extern uint8 MONITOR_errorStatus;
    extern volatile uint8 MONITOR_rxBuffer[MONITOR_RX_BUFFER_SIZE];
    extern volatile uint8 MONITOR_rxBufferRead;
    extern volatile uint8 MONITOR_rxBufferWrite;
    extern volatile uint8 MONITOR_rxBufferLoopDetect;
    extern volatile uint8 MONITOR_rxBufferOverflow;
    #if (MONITOR_RXHW_ADDRESS_ENABLED)
        extern volatile uint8 MONITOR_rxAddressMode;
        extern volatile uint8 MONITOR_rxAddressDetected;
    #endif /* (MONITOR_RXHW_ADDRESS_ENABLED) */
#endif /* (MONITOR_RX_INTERRUPT_ENABLED && (MONITOR_RX_ENABLED || MONITOR_HD_ENABLED)) */


/***************************************
* Enumerated Types and Parameters
***************************************/

#define MONITOR__B_UART__AM_SW_BYTE_BYTE 1
#define MONITOR__B_UART__AM_SW_DETECT_TO_BUFFER 2
#define MONITOR__B_UART__AM_HW_BYTE_BY_BYTE 3
#define MONITOR__B_UART__AM_HW_DETECT_TO_BUFFER 4
#define MONITOR__B_UART__AM_NONE 0

#define MONITOR__B_UART__NONE_REVB 0
#define MONITOR__B_UART__EVEN_REVB 1
#define MONITOR__B_UART__ODD_REVB 2
#define MONITOR__B_UART__MARK_SPACE_REVB 3



/***************************************
*    Initial Parameter Constants
***************************************/

/* UART shifts max 8 bits, Mark/Space functionality working if 9 selected */
#define MONITOR_NUMBER_OF_DATA_BITS    ((8u > 8u) ? 8u : 8u)
#define MONITOR_NUMBER_OF_STOP_BITS    (1u)

#if (MONITOR_RXHW_ADDRESS_ENABLED)
    #define MONITOR_RX_ADDRESS_MODE    (0u)
    #define MONITOR_RX_HW_ADDRESS1     (0u)
    #define MONITOR_RX_HW_ADDRESS2     (0u)
#endif /* (MONITOR_RXHW_ADDRESS_ENABLED) */

#define MONITOR_INIT_RX_INTERRUPTS_MASK \
                                  (uint8)((0 << MONITOR_RX_STS_FIFO_NOTEMPTY_SHIFT) \
                                        | (0 << MONITOR_RX_STS_MRKSPC_SHIFT) \
                                        | (0 << MONITOR_RX_STS_ADDR_MATCH_SHIFT) \
                                        | (0 << MONITOR_RX_STS_PAR_ERROR_SHIFT) \
                                        | (0 << MONITOR_RX_STS_STOP_ERROR_SHIFT) \
                                        | (0 << MONITOR_RX_STS_BREAK_SHIFT) \
                                        | (0 << MONITOR_RX_STS_OVERRUN_SHIFT))

#define MONITOR_INIT_TX_INTERRUPTS_MASK \
                                  (uint8)((0 << MONITOR_TX_STS_COMPLETE_SHIFT) \
                                        | (0 << MONITOR_TX_STS_FIFO_EMPTY_SHIFT) \
                                        | (0 << MONITOR_TX_STS_FIFO_FULL_SHIFT) \
                                        | (0 << MONITOR_TX_STS_FIFO_NOT_FULL_SHIFT))


/***************************************
*              Registers
***************************************/

#ifdef MONITOR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define MONITOR_CONTROL_REG \
                            (* (reg8 *) MONITOR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
    #define MONITOR_CONTROL_PTR \
                            (  (reg8 *) MONITOR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
#endif /* End MONITOR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(MONITOR_TX_ENABLED)
    #define MONITOR_TXDATA_REG          (* (reg8 *) MONITOR_BUART_sTX_TxShifter_u0__F0_REG)
    #define MONITOR_TXDATA_PTR          (  (reg8 *) MONITOR_BUART_sTX_TxShifter_u0__F0_REG)
    #define MONITOR_TXDATA_AUX_CTL_REG  (* (reg8 *) MONITOR_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define MONITOR_TXDATA_AUX_CTL_PTR  (  (reg8 *) MONITOR_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define MONITOR_TXSTATUS_REG        (* (reg8 *) MONITOR_BUART_sTX_TxSts__STATUS_REG)
    #define MONITOR_TXSTATUS_PTR        (  (reg8 *) MONITOR_BUART_sTX_TxSts__STATUS_REG)
    #define MONITOR_TXSTATUS_MASK_REG   (* (reg8 *) MONITOR_BUART_sTX_TxSts__MASK_REG)
    #define MONITOR_TXSTATUS_MASK_PTR   (  (reg8 *) MONITOR_BUART_sTX_TxSts__MASK_REG)
    #define MONITOR_TXSTATUS_ACTL_REG   (* (reg8 *) MONITOR_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)
    #define MONITOR_TXSTATUS_ACTL_PTR   (  (reg8 *) MONITOR_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)

    /* DP clock */
    #if(MONITOR_TXCLKGEN_DP)
        #define MONITOR_TXBITCLKGEN_CTR_REG        \
                                        (* (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define MONITOR_TXBITCLKGEN_CTR_PTR        \
                                        (  (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define MONITOR_TXBITCLKTX_COMPLETE_REG    \
                                        (* (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
        #define MONITOR_TXBITCLKTX_COMPLETE_PTR    \
                                        (  (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
    #else     /* Count7 clock*/
        #define MONITOR_TXBITCTR_PERIOD_REG    \
                                        (* (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define MONITOR_TXBITCTR_PERIOD_PTR    \
                                        (  (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define MONITOR_TXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define MONITOR_TXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define MONITOR_TXBITCTR_COUNTER_REG   \
                                        (* (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
        #define MONITOR_TXBITCTR_COUNTER_PTR   \
                                        (  (reg8 *) MONITOR_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
    #endif /* MONITOR_TXCLKGEN_DP */

#endif /* End MONITOR_TX_ENABLED */

#if(MONITOR_HD_ENABLED)

    #define MONITOR_TXDATA_REG             (* (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__F1_REG )
    #define MONITOR_TXDATA_PTR             (  (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__F1_REG )
    #define MONITOR_TXDATA_AUX_CTL_REG     (* (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)
    #define MONITOR_TXDATA_AUX_CTL_PTR     (  (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define MONITOR_TXSTATUS_REG           (* (reg8 *) MONITOR_BUART_sRX_RxSts__STATUS_REG )
    #define MONITOR_TXSTATUS_PTR           (  (reg8 *) MONITOR_BUART_sRX_RxSts__STATUS_REG )
    #define MONITOR_TXSTATUS_MASK_REG      (* (reg8 *) MONITOR_BUART_sRX_RxSts__MASK_REG )
    #define MONITOR_TXSTATUS_MASK_PTR      (  (reg8 *) MONITOR_BUART_sRX_RxSts__MASK_REG )
    #define MONITOR_TXSTATUS_ACTL_REG      (* (reg8 *) MONITOR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define MONITOR_TXSTATUS_ACTL_PTR      (  (reg8 *) MONITOR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End MONITOR_HD_ENABLED */

#if( (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) )
    #define MONITOR_RXDATA_REG             (* (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__F0_REG )
    #define MONITOR_RXDATA_PTR             (  (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__F0_REG )
    #define MONITOR_RXADDRESS1_REG         (* (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__D0_REG )
    #define MONITOR_RXADDRESS1_PTR         (  (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__D0_REG )
    #define MONITOR_RXADDRESS2_REG         (* (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__D1_REG )
    #define MONITOR_RXADDRESS2_PTR         (  (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__D1_REG )
    #define MONITOR_RXDATA_AUX_CTL_REG     (* (reg8 *) MONITOR_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define MONITOR_RXBITCTR_PERIOD_REG    (* (reg8 *) MONITOR_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define MONITOR_RXBITCTR_PERIOD_PTR    (  (reg8 *) MONITOR_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define MONITOR_RXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) MONITOR_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define MONITOR_RXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) MONITOR_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define MONITOR_RXBITCTR_COUNTER_REG   (* (reg8 *) MONITOR_BUART_sRX_RxBitCounter__COUNT_REG )
    #define MONITOR_RXBITCTR_COUNTER_PTR   (  (reg8 *) MONITOR_BUART_sRX_RxBitCounter__COUNT_REG )

    #define MONITOR_RXSTATUS_REG           (* (reg8 *) MONITOR_BUART_sRX_RxSts__STATUS_REG )
    #define MONITOR_RXSTATUS_PTR           (  (reg8 *) MONITOR_BUART_sRX_RxSts__STATUS_REG )
    #define MONITOR_RXSTATUS_MASK_REG      (* (reg8 *) MONITOR_BUART_sRX_RxSts__MASK_REG )
    #define MONITOR_RXSTATUS_MASK_PTR      (  (reg8 *) MONITOR_BUART_sRX_RxSts__MASK_REG )
    #define MONITOR_RXSTATUS_ACTL_REG      (* (reg8 *) MONITOR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define MONITOR_RXSTATUS_ACTL_PTR      (  (reg8 *) MONITOR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End  (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) */

#if(MONITOR_INTERNAL_CLOCK_USED)
    /* Register to enable or disable the digital clocks */
    #define MONITOR_INTCLOCK_CLKEN_REG     (* (reg8 *) MONITOR_IntClock__PM_ACT_CFG)
    #define MONITOR_INTCLOCK_CLKEN_PTR     (  (reg8 *) MONITOR_IntClock__PM_ACT_CFG)

    /* Clock mask for this clock. */
    #define MONITOR_INTCLOCK_CLKEN_MASK    MONITOR_IntClock__PM_ACT_MSK
#endif /* End MONITOR_INTERNAL_CLOCK_USED */


/***************************************
*       Register Constants
***************************************/

#if(MONITOR_TX_ENABLED)
    #define MONITOR_TX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End MONITOR_TX_ENABLED */

#if(MONITOR_HD_ENABLED)
    #define MONITOR_TX_FIFO_CLR            (0x02u) /* FIFO1 CLR */
#endif /* End MONITOR_HD_ENABLED */

#if( (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) )
    #define MONITOR_RX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End  (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

/* UART v2_40 obsolete definitions */
#define MONITOR_WAIT_1_MS      MONITOR_BL_CHK_DELAY_MS   

#define MONITOR_TXBUFFERSIZE   MONITOR_TX_BUFFER_SIZE
#define MONITOR_RXBUFFERSIZE   MONITOR_RX_BUFFER_SIZE

#if (MONITOR_RXHW_ADDRESS_ENABLED)
    #define MONITOR_RXADDRESSMODE  MONITOR_RX_ADDRESS_MODE
    #define MONITOR_RXHWADDRESS1   MONITOR_RX_HW_ADDRESS1
    #define MONITOR_RXHWADDRESS2   MONITOR_RX_HW_ADDRESS2
    /* Backward compatible define */
    #define MONITOR_RXAddressMode  MONITOR_RXADDRESSMODE
#endif /* (MONITOR_RXHW_ADDRESS_ENABLED) */

/* UART v2_30 obsolete definitions */
#define MONITOR_initvar                    MONITOR_initVar

#define MONITOR_RX_Enabled                 MONITOR_RX_ENABLED
#define MONITOR_TX_Enabled                 MONITOR_TX_ENABLED
#define MONITOR_HD_Enabled                 MONITOR_HD_ENABLED
#define MONITOR_RX_IntInterruptEnabled     MONITOR_RX_INTERRUPT_ENABLED
#define MONITOR_TX_IntInterruptEnabled     MONITOR_TX_INTERRUPT_ENABLED
#define MONITOR_InternalClockUsed          MONITOR_INTERNAL_CLOCK_USED
#define MONITOR_RXHW_Address_Enabled       MONITOR_RXHW_ADDRESS_ENABLED
#define MONITOR_OverSampleCount            MONITOR_OVER_SAMPLE_COUNT
#define MONITOR_ParityType                 MONITOR_PARITY_TYPE

#if( MONITOR_TX_ENABLED && (MONITOR_TXBUFFERSIZE > MONITOR_FIFO_LENGTH))
    #define MONITOR_TXBUFFER               MONITOR_txBuffer
    #define MONITOR_TXBUFFERREAD           MONITOR_txBufferRead
    #define MONITOR_TXBUFFERWRITE          MONITOR_txBufferWrite
#endif /* End MONITOR_TX_ENABLED */
#if( ( MONITOR_RX_ENABLED || MONITOR_HD_ENABLED ) && \
     (MONITOR_RXBUFFERSIZE > MONITOR_FIFO_LENGTH) )
    #define MONITOR_RXBUFFER               MONITOR_rxBuffer
    #define MONITOR_RXBUFFERREAD           MONITOR_rxBufferRead
    #define MONITOR_RXBUFFERWRITE          MONITOR_rxBufferWrite
    #define MONITOR_RXBUFFERLOOPDETECT     MONITOR_rxBufferLoopDetect
    #define MONITOR_RXBUFFER_OVERFLOW      MONITOR_rxBufferOverflow
#endif /* End MONITOR_RX_ENABLED */

#ifdef MONITOR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define MONITOR_CONTROL                MONITOR_CONTROL_REG
#endif /* End MONITOR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(MONITOR_TX_ENABLED)
    #define MONITOR_TXDATA                 MONITOR_TXDATA_REG
    #define MONITOR_TXSTATUS               MONITOR_TXSTATUS_REG
    #define MONITOR_TXSTATUS_MASK          MONITOR_TXSTATUS_MASK_REG
    #define MONITOR_TXSTATUS_ACTL          MONITOR_TXSTATUS_ACTL_REG
    /* DP clock */
    #if(MONITOR_TXCLKGEN_DP)
        #define MONITOR_TXBITCLKGEN_CTR        MONITOR_TXBITCLKGEN_CTR_REG
        #define MONITOR_TXBITCLKTX_COMPLETE    MONITOR_TXBITCLKTX_COMPLETE_REG
    #else     /* Count7 clock*/
        #define MONITOR_TXBITCTR_PERIOD        MONITOR_TXBITCTR_PERIOD_REG
        #define MONITOR_TXBITCTR_CONTROL       MONITOR_TXBITCTR_CONTROL_REG
        #define MONITOR_TXBITCTR_COUNTER       MONITOR_TXBITCTR_COUNTER_REG
    #endif /* MONITOR_TXCLKGEN_DP */
#endif /* End MONITOR_TX_ENABLED */

#if(MONITOR_HD_ENABLED)
    #define MONITOR_TXDATA                 MONITOR_TXDATA_REG
    #define MONITOR_TXSTATUS               MONITOR_TXSTATUS_REG
    #define MONITOR_TXSTATUS_MASK          MONITOR_TXSTATUS_MASK_REG
    #define MONITOR_TXSTATUS_ACTL          MONITOR_TXSTATUS_ACTL_REG
#endif /* End MONITOR_HD_ENABLED */

#if( (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) )
    #define MONITOR_RXDATA                 MONITOR_RXDATA_REG
    #define MONITOR_RXADDRESS1             MONITOR_RXADDRESS1_REG
    #define MONITOR_RXADDRESS2             MONITOR_RXADDRESS2_REG
    #define MONITOR_RXBITCTR_PERIOD        MONITOR_RXBITCTR_PERIOD_REG
    #define MONITOR_RXBITCTR_CONTROL       MONITOR_RXBITCTR_CONTROL_REG
    #define MONITOR_RXBITCTR_COUNTER       MONITOR_RXBITCTR_COUNTER_REG
    #define MONITOR_RXSTATUS               MONITOR_RXSTATUS_REG
    #define MONITOR_RXSTATUS_MASK          MONITOR_RXSTATUS_MASK_REG
    #define MONITOR_RXSTATUS_ACTL          MONITOR_RXSTATUS_ACTL_REG
#endif /* End  (MONITOR_RX_ENABLED) || (MONITOR_HD_ENABLED) */

#if(MONITOR_INTERNAL_CLOCK_USED)
    #define MONITOR_INTCLOCK_CLKEN         MONITOR_INTCLOCK_CLKEN_REG
#endif /* End MONITOR_INTERNAL_CLOCK_USED */

#define MONITOR_WAIT_FOR_COMLETE_REINIT    MONITOR_WAIT_FOR_COMPLETE_REINIT

#endif  /* CY_UART_MONITOR_H */


/* [] END OF FILE */
