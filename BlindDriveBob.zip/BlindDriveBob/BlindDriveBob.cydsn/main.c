/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>

#define VERSION     "V1.0"

//device ID
#define MOTOR0  0
#define MOTOR1  1
#define MOTOR2  2
#define MONITOR 3

//opcodes for Maxon Motors
#define WRITEOBJECT 0x11

//Maxon Motors node ids
#define NODEID  0x01

//registers Maxon motors
#define CONTROLWORD 0x6040
#define TARGETPOSITION 0x607A
#define VELOCITY 0x6081
#define ACCELERATION 0x6083
#define DECELERATION 0x6084

//Maxon Motors constant values
#define MAXVELOCITY 2000
#define MAXACCELERATION 10000//same value for deceleration

//Conversion between angle and Motor encoder pulses
#define GAIN 5120*4/360

//Checksum for Maxon Motor Frames
uint16 CalcFieldCRC(uint16*, uint16);

//Read and Writes for Maxon Motors
void writeObject(uint16,uint8,uint8,uint16);
void readtest(uint16 index,uint8 nodeid,uint8 subindex);
void Write32Bit(uint16 index, uint8 nodeid, uint8 subindex, int data, uint8 motor);

//Sending and Recieving individual bytes for Maxon Motors
void PutChar(uint8 device,uint8 data);
uint8 GetChar(uint8 device);

//Maxon Motor Control Functions
void SetMotorParameters(uint8 motor);
void EnableMotor(uint8 motor);
void FaultReset(uint8 motor);

//Converts angles from IMU to encoder pulses for Maxon Motors
int pulseConverter(uint16);


int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    MONITOR_Start();
    MOTOR1_Start();
    MONITOR_PutString("\n\rBlind Drive Bob ");
    while(!MONITOR_TX_STS_COMPLETE)
    {}
    MONITOR_PutString(VERSION);
    while(!MONITOR_TX_STS_COMPLETE)
    {}
    MONITOR_PutCRLF('.');
    while(!MONITOR_TX_STS_COMPLETE)
    {}
    CyDelay(100);
    
    
    FaultReset(MOTOR1);
    EnableMotor(MOTOR1);
    SetMotorParameters(MOTOR1);
    
    uint8 i=0;
    for(;;)
    {
        Write32Bit(TARGETPOSITION,NODEID,0x00,2000*i,MOTOR1);
        //enable motor
        Write32Bit(CONTROLWORD,NODEID,0x00,0x3F,MOTOR1);
        CyDelay(100);
        i++;
    }
}

uint16 CalcFieldCRC(uint16* pDataArray, uint16 numberOfWords)
{
    uint16 shifter, c;
    uint16 carry;
    uint16 CRC = 0;
    //Calculate pDataArray Word by Word
    while(numberOfWords--)
    {
        shifter = 0x8000;
        c = *pDataArray++;
        do
        {
            //Initialize BitX to Bit15
            //Copy next DataWord to c
            carry = CRC & 0x8000;
            CRC <<= 1;
            if(c & shifter) CRC++;
            if(carry) CRC ^= 0x1021;
            shifter >>= 1;
            //Check if Bit15 of CRC is set
            //CRC = CRC * 2
            //CRC = CRC + 1, if BitX is set in c
            //CRC = CRC XOR G(x), if carry is true
            //Set BitX to next lower Bit, shifter = shifter/2
        } while(shifter);
    }
    return CRC;
}

void readtest(uint16 index, uint8 nodeid, uint8 subindex)
{
     MOTOR1_PutChar(0x10);
        while(!MOTOR1_TX_STS_COMPLETE)
        {}
        /*while(1)
        { 
            if(MOTOR1_RX_STS_FIFO_NOTEMPTY)
            {
                recievedata=MOTOR1_GetChar();
                newdata=1;
            }
            if(newdata==1)
            {
                temp=recievedata;
                MONITOR_PutChar(temp);
                while(!MONITOR_TX_STS_COMPLETE)
                {}
                newdata=0;
                if(recievedata=='O')
                {
                    MONITOR_PutString("Opcode recieved and okay");
                    MONITOR_PutCRLF('.');
                    while(!MONITOR_TX_STS_COMPLETE)
                    {}
                    break;
                }
                else if(recievedata=='F')
                {
                    MONITOR_PutString("Opcode failed");
                    MONITOR_PutCRLF('.');
                    while(!MONITOR_TX_STS_COMPLETE)
                    {}
                    break;
                }
            }
        }*/
        MOTOR1_PutChar(0x01);//length
        while(!MOTOR1_TX_STS_COMPLETE)
        {}
        //writeObject(0x6040,0x00,NODEID,0x80);
        MOTOR1_PutChar(0xFF&index);//index lsb
        MOTOR1_PutChar((0xFF00&index)>>8);//index msb
        //node id
        MOTOR1_PutChar(nodeid);
        //subindex
        MOTOR1_PutChar(subindex);
        
        //crc
        uint16 datacheck[]={0x1001,index,(subindex<<8)|nodeid,0x0000};
        uint16 crc=CalcFieldCRC(datacheck,4);
        MOTOR1_PutChar(crc&0xFF);
        MOTOR1_PutChar((crc&0xFF00)>>8);
        /*while(1)
        { 
            if(MOTOR1_RX_STS_FIFO_NOTEMPTY)
            {
                recievedata=MOTOR1_GetChar();
                newdata=1;
            }
            if(newdata==1)
            {
                temp=recievedata;
                MONITOR_PutChar(temp);
                while(!MONITOR_TX_STS_COMPLETE)
                {}
                newdata=0;
                if(recievedata=='O')
                {
                    MONITOR_PutString("data recieved and okay");
                    MONITOR_PutCRLF('.');
                    while(!MONITOR_TX_STS_COMPLETE)
                    {}
                    MOTOR1_PutChar('O');
                    break;
                }
                else if(recievedata=='F')
                {
                    MONITOR_PutString("data failed");
                    MONITOR_PutCRLF('.');
                    while(!MONITOR_TX_STS_COMPLETE)
                    {}
                    break;
                }
            }
        }*/
        /*while(MOTOR1_RX_STS_FIFO_NOTEMPTY)
        {
            temp=MOTOR1_GetChar();
            MONITOR_PutChar(temp);
            if(temp==0x00)
            {
                MONITOR_PutString("Answer:");
                break;
            }
        }*/
        //MOTOR1_PutChar('O');
        /*while(MOTOR1_RX_STS_FIFO_NOTEMPTY)
        {
            temp=MOTOR1_GetChar();
            MONITOR_PutChar(temp);
        }
        MONITOR_PutCRLF(' ');*/
}

void Write32Bit(uint16 index, uint8 nodeid, uint8 subindex, int data, uint8 motor)
{
    uint8 length=3;
    //frame used to send
    uint16 frame[]={WRITEOBJECT<<8|length,index,nodeid<<8|subindex,0xFFFF&data,0xFFFF0000&data,0x0000};
    //calculate crc and put in frame
    frame[5]=CalcFieldCRC(frame,6);
    
    //send frame
    //opcode, length, index (lsb,msb), (subindex,nodeid), data lsb, data msb, crc (lsb,msb)
    uint8 i=0;
    PutChar(motor,(frame[0]&0xFF00)>>8);//opcode
    PutChar(motor,frame[0]&0xFF);//length
    for(i=1;i<=5;i++)
    {
        PutChar(motor,frame[i]&0xFF);
        PutChar(motor,(frame[i]&0xFF00)>>8);
    }
    
    //wait until driver responds
    uint8 recieve=0;
    while(1)
    {
        if(MOTOR1_RX_STS_FIFO_NOTEMPTY)
        {
            recieve=GetChar(motor);
        }
        if(recieve=='O')
        {
            break;
        }
        else if(recieve=='F')
        {
            return;
        }
    }
    
    //recieve answer frame
    i=0;
    uint8 framestart=0,newbit=0,count=0;
    while(i<255)
    {
        if(MOTOR1_RX_STS_FIFO_NOTEMPTY)
        {//read a byte from buffer
            newbit=1;
            recieve=GetChar(motor);
        }
        if(newbit==0);
        else if((recieve==0x00)&(framestart==0))
        {//beginning of answer frame
            framestart=1;
            //acknowledge start of answer frame
            PutChar(motor,'O');
            newbit=0;
        }
        else
        {
            count++;
            newbit=0;
        }
        if(count>=8)
        {
            break;
        }
        i++;
    }
    //acknowledge end of frame
    PutChar(motor,'O');
}

void EnableMotor(uint8 motor)
{
    //enable sequence 87 06 0f
    //CyDelay(1000);
    
    //enable
    Write32Bit(CONTROLWORD,NODEID,0x00,0x87,motor);
    Write32Bit(CONTROLWORD,NODEID,0x00,0x06,motor);
    Write32Bit(CONTROLWORD,NODEID,0x00,0x0F,motor);
}

int pulseConverter(uint16 angle)
{//not yet implemented
    return (int)GAIN*angle;
}

void FaultReset(uint8 motor)
{
    //clear fault
    Write32Bit(CONTROLWORD,0x01,0x00,0x06,motor);
    Write32Bit(CONTROLWORD,0x01,0x00,0x7,motor);    
    Write32Bit(CONTROLWORD,0x01,0x00,0xF,motor);
}

void PutChar(uint8 device,uint8 data)
{//motor0 and motor2 write to motor 1
    switch(device)
    {
        case MOTOR0:
            MOTOR1_PutChar(data);
            break;
        case MOTOR1:
            MOTOR1_PutChar(data);
            break;
        case MOTOR2:
            MOTOR1_PutChar(data);
            break;
        case MONITOR:
            MONITOR_PutChar(data);
            break;
    }
}

uint8 GetChar(uint8 device)
{//motor0 and motor2 read from motor 1
    switch(device)
    {
        case MOTOR0:
            return MOTOR1_GetChar();
            break;
        case MOTOR1:
            return MOTOR1_GetChar();
            break;
        case MOTOR2:
            return MOTOR1_GetChar();
            break;
        case MONITOR:
        default:
            return MONITOR_GetChar();
    }
}

void SetMotorParameters(uint8 motor)
{//motor0 and motor2 write to motor1
    switch(motor)
    {
        case MOTOR0:
            //set max velocity
            Write32Bit(VELOCITY,0x01,0x00,MAXVELOCITY, MOTOR1);
            //set max acceleration
            Write32Bit(ACCELERATION,0x01,0x00,MAXACCELERATION,MOTOR1);
            //set max deceleration
            Write32Bit(DECELERATION,0x01,0x00,MAXACCELERATION,MOTOR1);
            break;
        case MOTOR1:
            Write32Bit(VELOCITY,0x01,0x00,MAXVELOCITY, MOTOR1);
            //set max acceleration
            Write32Bit(ACCELERATION,0x01,0x00,MAXACCELERATION,MOTOR1);
            //set max deceleration
            Write32Bit(DECELERATION,0x01,0x00,MAXACCELERATION,MOTOR1);
            break;
        
        case MOTOR2:
            Write32Bit(VELOCITY,0x01,0x00,MAXVELOCITY, MOTOR1);
            //set max acceleration
            Write32Bit(ACCELERATION,0x01,0x00,MAXACCELERATION,MOTOR1);
            //set max deceleration
            Write32Bit(DECELERATION,0x01,0x00,MAXACCELERATION,MOTOR1);
            break;
    }
}
